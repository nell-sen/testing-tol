import { useEffect, useRef, useState } from 'react';
import { useMusicStore } from '../store/useMusicStore';
import ReactPlayer from 'react-player';
import toast from 'react-hot-toast';
import { isYouTubeUrl } from '../services/streamService';

export function GlobalAudioPlayer() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const playerRef = useRef<any>(null);
  const Player = ReactPlayer as any;
  const [isReady, setIsReady] = useState(false);
  // Track what URL is currently loaded in the audio element
  const loadedUrlRef = useRef<string>('');
  
  const { 
    songs, 
    currentSongIndex, 
    isPlaying, 
    setIsPlaying, 
    volume, 
    setCurrentSongIndex,
    isShuffle,
    isRepeat,
    setCurrentTime,
    setDuration
  } = useMusicStore();
  
  const currentSong = currentSongIndex >= 0 ? songs[currentSongIndex] : null;
  const audioUrl = currentSong?.audioUrl || '';
  const isYT = isYouTubeUrl(audioUrl);

  const handleTrackEnded = () => {
    if (isRepeat) {
      if (isYT && playerRef.current) {
        playerRef.current.seekTo(0);
      } else if (audioRef.current) {
        audioRef.current.currentTime = 0;
        audioRef.current.play().catch(() => {});
      }
      return;
    }

    if (isShuffle) {
      setCurrentSongIndex(Math.floor(Math.random() * songs.length));
      return;
    }

    if (currentSongIndex + 1 < songs.length) {
      setCurrentSongIndex(currentSongIndex + 1);
    } else {
      setIsPlaying(false);
      setCurrentSongIndex(0);
    }
  };

  // Initialize audio element once
  useEffect(() => {
    if (!audioRef.current) {
      const audio = new Audio();
      audio.preload = 'auto';
      audio.crossOrigin = 'anonymous';
      audioRef.current = audio;
    }
  }, []);

  // ----- Event listeners (stable) -----
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    
    const onEnded = () => handleTrackEnded();
    const onTimeUpdate = () => { if (!isYT) setCurrentTime(audio.currentTime); };
    const onLoadedMetadata = () => { if (!isYT) setDuration(audio.duration); };
    const onPlay = () => { if (!isYT) setIsPlaying(true); };
    const onPause = () => { if (!isYT) setIsPlaying(false); };
    const onError = () => {
      if (!isYT && audio.src && audio.src !== window.location.href) {
        console.error("Local audio error on src:", audio.src);
        toast.error('Gagal memutar audio lokal, melewati...');
        handleTrackEnded();
      }
    };

    audio.addEventListener('ended', onEnded);
    audio.addEventListener('timeupdate', onTimeUpdate);
    audio.addEventListener('loadedmetadata', onLoadedMetadata);
    audio.addEventListener('play', onPlay);
    audio.addEventListener('pause', onPause);
    audio.addEventListener('error', onError);
    
    return () => {
      audio.removeEventListener('ended', onEnded);
      audio.removeEventListener('timeupdate', onTimeUpdate);
      audio.removeEventListener('loadedmetadata', onLoadedMetadata);
      audio.removeEventListener('play', onPlay);
      audio.removeEventListener('pause', onPause);
      audio.removeEventListener('error', onError);
    };
  }, [isYT, songs.length, currentSongIndex, isShuffle, isRepeat]);

  // ----- Volume sync -----
  useEffect(() => {
    if (audioRef.current) audioRef.current.volume = volume;
  }, [volume]);

  // ----- URL Change: load new track immediately -----
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isYT) {
      // Pause native audio if YT takes over
      if (!audio.paused) audio.pause();
      return;
    }

    if (!audioUrl) {
      audio.pause();
      audio.src = '';
      loadedUrlRef.current = '';
      return;
    }

    // Only reload if the URL actually changed
    if (loadedUrlRef.current !== audioUrl) {
      loadedUrlRef.current = audioUrl;
      audio.src = audioUrl;
      // Calling load() immediately starts buffering — eliminates the delay
      audio.load();

      if (isPlaying) {
        // play() after load() — browser starts downloading & plays ASAP
        const playPromise = audio.play();
        if (playPromise !== undefined) {
          playPromise.catch((e) => {
            if (e.name !== 'AbortError') {
              console.warn('Autoplay blocked:', e);
              setIsPlaying(false);
            }
          });
        }
      }
    }
  }, [audioUrl, isYT]);

  // ----- isPlaying state sync (for same track play/pause) -----
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio || isYT || !audioUrl) return;

    // Don't act if URL not yet loaded into element (the URL effect above handles that)
    if (loadedUrlRef.current !== audioUrl) return;

    if (isPlaying && audio.paused) {
      const playPromise = audio.play();
      if (playPromise !== undefined) {
        playPromise.catch((e) => {
          if (e.name !== 'AbortError') setIsPlaying(false);
        });
      }
    } else if (!isPlaying && !audio.paused) {
      audio.pause();
    }
  }, [isPlaying, isYT, audioUrl]);

  // Reset ready state when changing track
  useEffect(() => {
    setIsReady(false);
  }, [audioUrl]);

  // Expose Global API for UI to scrub time
  useEffect(() => {
    window.globalAudioRef = {
      get currentTime() { return useMusicStore.getState().currentTime; },
      set currentTime(val) {
        if (isYT && playerRef.current) {
          playerRef.current.seekTo(val, 'seconds');
        } else if (audioRef.current) {
          audioRef.current.currentTime = val;
        }
      },
      get duration() { return useMusicStore.getState().duration; },
      play: () => {
        setIsPlaying(true);
        // Also trigger native audio play immediately inside user gesture
        if (!isYT && audioRef.current && audioRef.current.paused) {
          audioRef.current.play().catch(() => {});
        }
        return Promise.resolve();
      },
      pause: () => {
        setIsPlaying(false);
        if (!isYT && audioRef.current && !audioRef.current.paused) {
          audioRef.current.pause();
        }
      },
    } as any;
  }, [isYT]);

  return (
    <div
      style={{
        position: 'fixed',
        left: '-9999px',
        top: 0,
        width: '320px',
        height: '180px',
        opacity: 0,
        pointerEvents: 'none',
        zIndex: -1,
      }}
      aria-hidden="true"
    >
      {isYT && (
        <Player
          ref={playerRef}
          url={audioUrl}
          playing={isPlaying}
          volume={volume}
          width="320px"
          height="180px"
          playsinline={true}
          controls={false}
          fallback={<div />}
          onReady={() => {
            setIsReady(true);
            if (playerRef.current) {
              const dur = playerRef.current.getDuration();
              if (dur) setDuration(dur);
            }
            if (isPlaying) {
              try {
                const internal = playerRef.current?.getInternalPlayer?.();
                internal?.playVideo?.();
              } catch {}
            }
          }}
          onPlay={() => setIsPlaying(true)}
          onPause={() => {
            const internal = playerRef.current?.getInternalPlayer?.();
            if (internal && typeof internal.getPlayerState === 'function') {
              const state = internal.getPlayerState();
              if (state === 2) setIsPlaying(false);
            }
          }}
          onProgress={(p: any) => {
            if (isReady) setCurrentTime(p.playedSeconds);
          }}
          onEnded={handleTrackEnded}
          onError={(e: any) => {
            console.error('YouTube Player Error:', e);
            toast.error('Gagal memuat video YouTube ini, melewati...');
            handleTrackEnded();
          }}
          config={{
            youtube: {
              playerVars: {
                autoplay: 1,
                controls: 0,
                showinfo: 0,
                rel: 0,
                modestbranding: 1,
                iv_load_policy: 3,
                playsinline: 1,
                origin: window.location.origin,
              },
            },
          }}
        />
      )}
    </div>
  );
}

declare global {
  interface Window {
    globalAudioRef: HTMLAudioElement;
  }
}
