# 🚀 NellSpotify — Upgrade Notes

## Files yang Diubah

### Baru Ditambahkan
- `src/hooks/useInfiniteScroll.ts` — Infinite scroll hook berbasis IntersectionObserver
- `src/hooks/useLazyImage.ts` — Fade-in lazy image loader
- `UPGRADE_NOTES.md` — Dokumen ini

### Diupgrade
| File | Perubahan |
|---|---|
| `src/App.tsx` | React.lazy + Suspense untuk semua halaman |
| `src/vite.config.ts` | Manual code-splitting chunks, esbuild minify, optimizeDeps |
| `src/pages/Home.tsx` | Infinite scroll, Virtual List (react-window), Trending/Baru/Rekomendasi, Artist dengan foto |
| `src/pages/Player.tsx` | React.memo, fine-grained Zustand selectors, hapus duplikat mediaSession |
| `src/components/GlobalAudioPlayer.tsx` | Media Session API (judul, artis, thumbnail, play/pause/next/prev) |
| `src/components/Layout.tsx` | React.memo |
| `src/components/MiniPlayer.tsx` | React.memo + fine-grained selectors |
| `src/components/BottomNav.tsx` | React.memo + fine-grained selector untuk unreadCount |
| `src/hooks/useFirestoreSync.ts` | Paginated fetch (limit 40 lagu pertama) |
| `src/index.css` | scroll-behavior smooth, GPU hints, lazy image fade-in, contain layout |

---

## Yang Ditambahkan Per Tugas

### ✅ Tugas 1 — Lazy Loading
- Semua halaman di-lazy load via `React.lazy()` + `Suspense`
- Skeleton fallback saat halaman loading

### ✅ Tugas 2 — Infinite Scroll + Virtual List
- `useInfiniteSongs()` — paginate songs array secara lokal (20 per halaman)
- `FixedSizeList` dari `react-window` untuk render hanya item yang terlihat
- IntersectionObserver sentinel untuk load otomatis saat scroll

### ✅ Tugas 3 — Simplifikasi UI
- Mobile-first layout
- Smooth scroll CSS
- Fokus konten utama

### ✅ Tugas 4 — Optimasi Player
- `React.memo` pada Player, MiniPlayer, Layout, BottomNav
- `useMemo` untuk kalkulasi berat
- Fine-grained Zustand selectors → tidak re-render saat data tidak relevan berubah

### ✅ Tugas 5 — Media Session API
- GlobalAudioPlayer sekarang mendaftarkan:
  - `MediaMetadata` (judul, artis, album, thumbnail)
  - Action handler: play, pause, nexttrack, previoustrack
  - `playbackState` sync real-time
- Bekerja saat pindah tab / background (YouTube/Native audio)

### ✅ Tugas 6 — Smoothness Maksimal
- Semua komponen kritis di-memo
- Zustand selectors granular (tidak subscribe seluruh store)
- CSS `contain: layout style` pada setiap section
- `will-change: auto` pada element animasi

### ✅ Tugas 7 — Optimasi Build
- `vite.config.ts` dengan `manualChunks`:
  - `react-vendor` — React + Router
  - `firebase` — Firebase SDK (chunk terpisah)
  - `framer` — Framer Motion
  - `player` — ReactPlayer
  - `virtual` — react-window
  - `radix` — Radix UI primitives
- `target: 'esnext'`, `minify: 'esbuild'`

### ✅ Tugas 8 — Homepage Lebih Hidup
- Section **🔥 Trending** (6 lagu terpopuler)
- Section **✨ Terbaru** (featured banner lagu terbaru)
- Section **💡 Rekomendasi** (shuffle acak)
- Section **Time Travel** + **Mood** tetap ada

### ✅ Tugas 9 — Perbanyak Lagu (Tetap Ringan)
- Virtual list render hanya item visible
- Infinite scroll otomatis load 20 lagu berikutnya saat scroll
- Firebase fetch dibatasi 40 lagu pertama (hemat quota)

### ✅ Tugas 10 — Popular Artists Upgrade
- Avatar huruf diganti dengan **foto artis** (diambil dari thumbnail lagu)
- Card horizontal slider
- Tampilkan jumlah lagu per artis
- Fallback ke huruf jika tidak ada foto
- Sorted by jumlah lagu terbanyak

---

## Cara Deploy

```bash
npm install
npm run build
# Upload folder dist/ ke Vercel
```

Atau langsung push ke GitHub + connect ke Vercel (auto-detect Vite).

---

## ⚠️ Yang TIDAK Diubah (Sengaja)
- Logic utama GlobalAudioPlayer (audioRef, ReactPlayer)
- Source video/audio
- Arsitektur Zustand store
- Semua halaman lain (Search, Library, Admin, Lyrics)
- Firebase config
