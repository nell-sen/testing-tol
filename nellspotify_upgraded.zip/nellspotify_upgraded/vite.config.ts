import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";
import { componentTagger } from "lovable-tagger";

export default defineConfig(({ mode }) => ({
  server: {
    host: "::",
    port: 8080,
    hmr: { overlay: false },
  },
  plugins: [react(), mode === "development" && componentTagger()].filter(Boolean),
  resolve: {
    alias: { "@": path.resolve(__dirname, "./src") },
    dedupe: [
      "react",
      "react-dom",
      "react/jsx-runtime",
      "react/jsx-dev-runtime",
      "@tanstack/react-query",
      "@tanstack/query-core",
    ],
  },
  build: {
    target: "esnext",
    minify: "esbuild",
    rollupOptions: {
      output: {
        // Manual chunk splitting for better caching
        manualChunks: {
          // Core React + Router
          "react-vendor": ["react", "react-dom", "react-router-dom"],
          // Animation
          "framer": ["framer-motion"],
          // Firebase (large — its own chunk)
          "firebase": ["firebase/app", "firebase/firestore"],
          // Media player
          "player": ["react-player"],
          // Virtual list
          "virtual": ["react-window"],
          // UI primitives (Radix)
          "radix": [
            "@radix-ui/react-dialog",
            "@radix-ui/react-dropdown-menu",
            "@radix-ui/react-slider",
            "@radix-ui/react-toast",
            "@radix-ui/react-avatar",
          ],
        },
      },
    },
    // Increase warning threshold slightly (we know firebase is large)
    chunkSizeWarningLimit: 600,
  },
  // Optimise deps pre-bundling
  optimizeDeps: {
    include: [
      "react",
      "react-dom",
      "react-router-dom",
      "zustand",
      "framer-motion",
      "react-window",
    ],
  },
}));
