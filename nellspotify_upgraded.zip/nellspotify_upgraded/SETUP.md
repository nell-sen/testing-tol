# NellSpotify — YouTube Music Player

## Cara Menjalankan
```bash
npm install      # atau: bun install
npm run dev      # Vite dev server di http://localhost:8080
npm run build    # Production build
```

## Cara Pakai (Quick Start)
1. Buka http://localhost:8080 → Halaman Home muncul
2. Di kotak **"Quick Import"**, paste link YouTube:
   - **Playlist:** `https://www.youtube.com/playlist?list=PLxxxx`
   - **Video tunggal:** `https://youtu.be/dQw4w9WgXcQ` atau `https://www.youtube.com/watch?v=...`
   - **YouTube Shorts:** `https://www.youtube.com/shorts/...`
3. Klik **Play** → lagu langsung diimpor & diputar (audio-only).
4. Buka tab **Library** → lihat semua lagu, klik untuk play.
5. Buka **Player** → kontrol next / prev / shuffle / repeat.

## Fitur
- ✅ Import playlist YouTube via YouTube Data API v3
- ✅ Auto-detect: video tunggal vs playlist
- ✅ Audio-only mode (iframe disembunyikan, audio tetap berbunyi)
- ✅ Next / Previous / Shuffle / Repeat / Autoplay
- ✅ State tersimpan lokal (Zustand + persist) — tidak butuh Firebase
- ✅ Optional: sinkronisasi ke Firestore (best-effort, tidak menghalangi UI)

## Default API Key
YouTube API key sudah di-embed: `AIzaSyB6vcGhQAkp0Gsi4GOuf4qZCZHY0Kak7cc`.
Bisa diganti via `/admin` → tab Settings (password admin: `Ishnelsen060906`).

## Struktur Penting
- `src/services/youtubeService.ts` — extract VIDEO_ID/PLAYLIST_ID + fetch playlist API
- `src/components/GlobalAudioPlayer.tsx` — pemutar global pakai react-player
- `src/components/QuickImport.tsx` — widget impor cepat di Home
- `src/store/useMusicStore.ts` — state Zustand (songs, currentIndex, dll)
- `src/hooks/useFirestoreSync.ts` — sync optional ke Firebase (gagal pun aman)

## Catatan
- Tidak ada download / convert MP3.
- Hanya pakai YouTube Data API resmi + YouTube IFrame API.
- Jika hosting di domain custom, pastikan `origin` di playerVars cocok.
