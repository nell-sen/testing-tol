export interface YouTubePlaylistItem {
  title: string;
  artist: string;
  thumbnail: string;
  videoId: string;
}

const DEFAULT_API_KEY = 'AIzaSyB6vcGhQAkp0Gsi4GOuf4qZCZHY0Kak7cc';

/**
 * Extract a YouTube playlist ID from any URL containing `list=` param.
 * Accepts: youtube.com/playlist?list=..., youtube.com/watch?v=...&list=..., or a raw playlist ID.
 */
export function extractPlaylistId(input: string): string | null {
  if (!input) return null;
  const trimmed = input.trim();
  const match = trimmed.match(/[?&]list=([A-Za-z0-9_-]+)/);
  if (match) return match[1];
  if (/^(PL|UU|FL|RD|OL|LL|EL|SP)[A-Za-z0-9_-]{10,}$/.test(trimmed)) return trimmed;
  return null;
}

/**
 * Extract a YouTube VIDEO_ID from any common YouTube URL format,
 * or return the raw 11-char ID if that's what was passed.
 */
export function extractVideoId(input: string): string | null {
  if (!input) return null;
  const trimmed = input.trim();
  if (/^[A-Za-z0-9_-]{11}$/.test(trimmed)) return trimmed;
  const patterns = [
    /(?:youtube\.com\/watch\?(?:.*&)?v=)([A-Za-z0-9_-]{11})/,
    /(?:youtu\.be\/)([A-Za-z0-9_-]{11})/,
    /(?:youtube\.com\/embed\/)([A-Za-z0-9_-]{11})/,
    /(?:youtube\.com\/shorts\/)([A-Za-z0-9_-]{11})/,
    /(?:youtube\.com\/v\/)([A-Za-z0-9_-]{11})/,
  ];
  for (const p of patterns) {
    const m = trimmed.match(p);
    if (m) return m[1];
  }
  return null;
}

export type YouTubeUrlKind =
  | { kind: 'playlist'; playlistId: string }
  | { kind: 'video'; videoId: string }
  | { kind: 'invalid' };

/**
 * Detect whether a YouTube URL is a playlist link or a single video.
 * If both `v=` and `list=` are present, prefer playlist.
 */
export function detectYouTubeUrl(input: string): YouTubeUrlKind {
  const playlistId = extractPlaylistId(input);
  if (playlistId) return { kind: 'playlist', playlistId };
  const videoId = extractVideoId(input);
  if (videoId) return { kind: 'video', videoId };
  return { kind: 'invalid' };
}

interface FetchOptions {
  tolerateErrors?: boolean;
}

export async function fetchYouTubePlaylist(
  apiKey: string,
  playlistUrl: string,
  options: FetchOptions = {}
): Promise<YouTubePlaylistItem[]> {
  const key = (apiKey && apiKey.trim()) || DEFAULT_API_KEY;

  const playlistId = extractPlaylistId(playlistUrl);
  if (!playlistId) {
    throw new Error('Link tidak valid. Pastikan URL mengandung parameter "list=".');
  }

  const allItems: YouTubePlaylistItem[] = [];
  // Anti-duplikat: track VIDEO_ID yang sudah dimasukkan, urutan asli dipertahankan
  const seenIds = new Set<string>();
  let nextPageToken = '';
  let pageCount = 0;

  do {
    pageCount++;
    const url =
      `https://www.googleapis.com/youtube/v3/playlistItems` +
      `?part=snippet&playlistId=${encodeURIComponent(playlistId)}&maxResults=50&key=${encodeURIComponent(key)}` +
      (nextPageToken ? `&pageToken=${encodeURIComponent(nextPageToken)}` : '');

    let response: Response;
    try {
      response = await fetch(url);
    } catch (e: any) {
      if (options.tolerateErrors && allItems.length) break;
      throw new Error(`Gagal menghubungi YouTube API: ${e?.message || 'network error'}`);
    }

    if (!response.ok) {
      let msg = `YouTube API ${response.status}`;
      try {
        const errorData = await response.json();
        msg = errorData?.error?.message || msg;
      } catch {}
      if (response.status === 404) {
        throw new Error('Playlist tidak ditemukan. Pastikan playlist publik atau unlisted.');
      }
      if (response.status === 403) {
        throw new Error(`Akses ditolak oleh YouTube API: ${msg}`);
      }
      if (options.tolerateErrors && allItems.length) break;
      throw new Error(msg);
    }

    const data = await response.json();
    nextPageToken = data.nextPageToken || '';

    const batch: YouTubePlaylistItem[] = (data.items || [])
      .map((item: any): YouTubePlaylistItem | null => {
        const videoId = item?.snippet?.resourceId?.videoId;
        if (!videoId) return null;
        // Skip jika VIDEO_ID sudah pernah ditemui di playlist ini
        if (seenIds.has(videoId)) return null;

        const rawTitle: string = item?.snippet?.title || '';
        if (rawTitle === 'Private video' || rawTitle === 'Deleted video') return null;

        let artist = 'Unknown Artist';
        let songTitle = rawTitle;

        if (rawTitle.includes(' - ')) {
          const [a, ...rest] = rawTitle.split(' - ');
          artist = a.trim();
          songTitle = rest.join(' - ').trim() || rawTitle;
        } else if (rawTitle.includes(' : ')) {
          const [a, ...rest] = rawTitle.split(' : ');
          artist = a.trim();
          songTitle = rest.join(' : ').trim() || rawTitle;
        } else if (item.snippet.videoOwnerChannelTitle) {
          artist = String(item.snippet.videoOwnerChannelTitle).replace(' - Topic', '').trim();
        }

        const thumbs = item.snippet.thumbnails || {};
        const thumbnail =
          thumbs.maxres?.url ||
          thumbs.standard?.url ||
          thumbs.high?.url ||
          thumbs.medium?.url ||
          thumbs.default?.url ||
          `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;

        return { title: songTitle, artist, thumbnail, videoId };
      })
      .filter(Boolean) as YouTubePlaylistItem[];

    // Tandai semua videoId batch ini setelah filter sukses
    for (const it of batch) seenIds.add(it.videoId);

    allItems.push(...batch);

    if (allItems.length >= 500 || pageCount >= 20) break;
  } while (nextPageToken);

  if (!allItems.length) {
    throw new Error('Playlist kosong atau seluruh video tidak dapat diakses.');
  }

  return allItems;
}

/**
 * Fetch metadata for a single YouTube video.
 */
export async function fetchYouTubeVideo(
  apiKey: string,
  videoId: string
): Promise<YouTubePlaylistItem> {
  const key = (apiKey && apiKey.trim()) || DEFAULT_API_KEY;
  const url = `https://www.googleapis.com/youtube/v3/videos?part=snippet&id=${encodeURIComponent(
    videoId
  )}&key=${encodeURIComponent(key)}`;

  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`YouTube API ${response.status}`);
    const data = await response.json();
    const item = data?.items?.[0];
    if (!item) throw new Error('Video tidak ditemukan');

    const rawTitle: string = item.snippet?.title || `Video ${videoId}`;
    let artist = item.snippet?.channelTitle?.replace(' - Topic', '').trim() || 'Unknown Artist';
    let songTitle = rawTitle;
    if (rawTitle.includes(' - ')) {
      const [a, ...rest] = rawTitle.split(' - ');
      artist = a.trim();
      songTitle = rest.join(' - ').trim();
    }
    const thumbs = item.snippet?.thumbnails || {};
    const thumbnail =
      thumbs.maxres?.url ||
      thumbs.high?.url ||
      thumbs.medium?.url ||
      thumbs.default?.url ||
      `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;

    return { title: songTitle, artist, thumbnail, videoId };
  } catch {
    return {
      title: `YouTube Video`,
      artist: 'Unknown Artist',
      thumbnail: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
      videoId,
    };
  }
}
