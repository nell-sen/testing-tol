// Legacy placeholder - app uses /pages/Home as root via Layout
export { Home as default } from './Home';
