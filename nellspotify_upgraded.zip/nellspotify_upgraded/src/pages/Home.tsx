import { Link, useNavigate } from 'react-router-dom';
import { useMusicStore } from '../store/useMusicStore';
import { motion } from 'framer-motion';
import React, { useState, useEffect, useCallback, memo } from 'react';
import { FixedSizeList as List } from 'react-window';
import { useInfiniteSongs } from '../hooks/useInfiniteScroll';

// ─── Memoised sub-components to avoid re-renders ───────────────────

const SongRow = memo(({ index, style, data }: { index: number; style: React.CSSProperties; data: { songs: any[]; onPlay: (i: number) => void } }) => {
  const song = data.songs[index];
  if (!song) return <div style={style} />;
  return (
    <div style={{ ...style, paddingBottom: 8 }}>
      <motion.div
        whileTap={{ scale: 0.97 }}
        onClick={() => data.onPlay(index)}
        className="flex items-center gap-3 px-3 py-2.5 rounded-xl cursor-pointer hover:bg-white/8 active:bg-white/12 transition-colors group"
      >
        <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0 shadow-md">
          <img
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            src={song.thumbnail}
            alt={song.title}
            loading="lazy"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-bold truncate text-slate-100 group-hover:text-[#ff4e00] transition-colors">{song.title}</p>
          <p className="text-xs text-slate-400 truncate">{song.artist}</p>
        </div>
        <span className="material-symbols-outlined text-slate-600 group-hover:text-[#ff4e00] transition-colors text-[18px] opacity-0 group-hover:opacity-100">play_circle</span>
      </motion.div>
    </div>
  );
});
SongRow.displayName = 'SongRow';

const ArtistCard = memo(({ artist, thumbnail, playCount, onClick }: { artist: string; thumbnail?: string; playCount: number; onClick: () => void }) => (
  <motion.div
    whileHover={{ y: -4 }}
    whileTap={{ scale: 0.95 }}
    onClick={onClick}
    className="flex flex-col items-center gap-2 flex-shrink-0 group cursor-pointer w-24"
  >
    <div className="w-20 h-20 rounded-full overflow-hidden shadow-xl border border-white/10 group-hover:border-[#ff4e00]/40 transition-all duration-300 bg-zinc-800">
      {thumbnail ? (
        <img src={thumbnail} alt={artist} loading="lazy" referrerPolicy="no-referrer" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
      ) : (
        <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-[#ff4e00]/20 to-zinc-800">
          <span className="font-black text-2xl text-[#ff4e00]">{artist.charAt(0).toUpperCase()}</span>
        </div>
      )}
    </div>
    <span className="text-xs font-bold text-center truncate w-full text-slate-300 group-hover:text-white transition-colors">{artist}</span>
    <span className="text-[10px] text-[#ff4e00] font-bold flex items-center gap-1">
      <span>🔥</span>
      <span>{playCount} songs</span>
    </span>
  </motion.div>
));
ArtistCard.displayName = 'ArtistCard';

const SongCard = memo(({ song, index, onPlay }: { song: any; index: number; onPlay: (i: number) => void }) => (
  <motion.div
    whileHover={{ y: -5 }}
    whileTap={{ scale: 0.95 }}
    onClick={() => onPlay(index)}
    className="flex-shrink-0 w-36 group cursor-pointer"
  >
    <div className="w-36 h-36 rounded-xl overflow-hidden mb-2 shadow-xl relative">
      <img
        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        src={song.thumbnail}
        alt={song.title}
        loading="lazy"
        referrerPolicy="no-referrer"
      />
      <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors" />
      <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
        <div className="w-10 h-10 bg-[#ff4e00] rounded-full flex items-center justify-center shadow-lg">
          <span className="material-symbols-outlined text-black text-[18px]" style={{ fontVariationSettings: "'FILL' 1" }}>play_arrow</span>
        </div>
      </div>
    </div>
    <p className="font-bold text-xs truncate text-slate-100 group-hover:text-[#ff4e00] transition-colors">{song.title}</p>
    <p className="text-[11px] text-slate-500 truncate">{song.artist}</p>
  </motion.div>
));
SongCard.displayName = 'SongCard';

// ─── Main Home Component ─────────────────────────────────────────────

export function Home() {
  const { songs: rawSongs, isLoading, setCurrentSongIndex, setIsPlaying, setIsCreatorOpen, setIsNotificationsOpen, notifications, setIsSearchOpen, appLogo } = useMusicStore();
  const [installPrompt, setInstallPrompt] = useState<any>(null);
  const navigate = useNavigate();

  // Deduplicate songs
  const songs = React.useMemo(() => {
    const seenIds = new Set<string>();
    const seenTA = new Set<string>();
    return rawSongs.filter((s) => {
      const k = `${s.title.trim().toLowerCase()}|||${s.artist.trim().toLowerCase()}`;
      if (seenIds.has(s.id) || seenTA.has(k)) return false;
      seenIds.add(s.id); seenTA.add(k);
      return true;
    });
  }, [rawSongs]);

  // Infinite scroll paginated songs
  const { displayedSongs, hasMore, sentinelRef } = useInfiniteSongs();

  // Derived data (memoised)
  const trendingSongs = React.useMemo(() => songs.slice(0, 6), [songs]);
  const newestSongs = React.useMemo(() => [...songs].sort((a, b) => b.createdAt - a.createdAt).slice(0, 10), [songs]);
  const recommendedSongs = React.useMemo(() => {
    const shuffled = [...songs].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, 10);
  }, [songs.length]);
  const artists = React.useMemo(() => {
    const map = new Map<string, { thumbnail: string; count: number }>();
    songs.forEach(s => {
      if (!map.has(s.artist)) map.set(s.artist, { thumbnail: s.thumbnail, count: 0 });
      map.get(s.artist)!.count++;
    });
    return Array.from(map.entries()).map(([artist, data]) => ({ artist, ...data })).sort((a, b) => b.count - a.count).slice(0, 8);
  }, [songs]);
  const albums = React.useMemo(() => {
    return Array.from(new Set(songs.map(s => s.album).filter(Boolean))).slice(0, 8).map(albumName => {
      const albumSongs = songs.filter(s => s.album === albumName);
      return { name: albumName, thumbnail: albumSongs[0]?.thumbnail, artist: albumSongs[0]?.artist };
    });
  }, [songs]);

  const unreadCount = notifications.filter(n => n.unread).length;

  useEffect(() => {
    const handler = (e: any) => { e.preventDefault(); setInstallPrompt(e); };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = async () => {
    if (!installPrompt) { alert('Sistem sedang menyiapkan paket instalasi...'); return; }
    installPrompt.prompt();
    const { outcome } = await installPrompt.userChoice;
    if (outcome === 'accepted') setInstallPrompt(null);
  };

  const handlePlay = useCallback((index: number) => {
    setCurrentSongIndex(index);
    setIsPlaying(true);
  }, [setCurrentSongIndex, setIsPlaying]);

  const itemVariants = {
    hidden: { y: 16, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: 'spring' as const, stiffness: 300, damping: 24 } }
  };

  const newestSong = newestSongs[0];
  const newestIndex = newestSong ? songs.findIndex(s => s.id === newestSong.id) : -1;

  return (
    <main className="pt-24 px-4 pb-40 space-y-8 w-full max-w-screen-2xl mx-auto relative z-10 font-sans">
      {/* Header */}
      <header className="fixed top-0 left-0 w-full z-50 bg-black/40 backdrop-blur-xl border-b border-white/5 py-4">
        <div className="max-w-screen-2xl mx-auto px-6 h-full flex justify-between items-center">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsCreatorOpen(true)}
              className="w-10 h-10 bg-[#ff4e00] rounded-2xl flex items-center justify-center transition-all active:scale-95 shadow-lg overflow-hidden shrink-0"
              title="Creator Info"
            >
              {appLogo ? (
                <img src={appLogo} alt="Logo" className="w-full h-full object-cover" loading="lazy" />
              ) : (
                <div className="w-5 h-5 bg-white rounded flex items-center justify-center">
                  <span className="text-[10px] font-black text-black">N</span>
                </div>
              )}
            </button>
            <span className="text-xl font-bold tracking-tighter text-slate-100 uppercase">NellSpotify</span>
          </div>
          <div className="flex gap-3 items-center">
            {installPrompt && (
              <button
                onClick={handleInstall}
                className="hidden md:flex items-center gap-2 bg-[#ff4e00] text-black px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-widest hover:brightness-110 transition-all active:scale-95"
              >
                <span className="material-symbols-outlined text-[14px]">install_mobile</span>
                Install PWA
              </button>
            )}
            <button onClick={() => setIsSearchOpen(true)} className="w-10 h-10 flex items-center justify-center rounded-full bg-white/5 hover:bg-white/10 transition-colors">
              <span className="material-symbols-outlined text-slate-300">search</span>
            </button>
            <button onClick={() => setIsNotificationsOpen(true)} className="w-10 h-10 flex items-center justify-center rounded-full bg-white/5 hover:bg-white/10 transition-colors relative">
              <span className="material-symbols-outlined text-slate-300">notifications</span>
              {unreadCount > 0 && <span className="absolute top-2 right-2 w-2 h-2 bg-[#ff4e00] rounded-full animate-pulse" />}
            </button>
            <div className="w-8 h-8 bg-gradient-to-tr from-slate-600 to-slate-400 rounded-full border border-white/20" />
          </div>
        </div>
      </header>

      {/* Quick Play Grid */}
      <section>
        <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight text-on-surface mb-4 text-glow">Good Morning</h1>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {isLoading ? (
            Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="glass-card rounded-xl p-2 flex items-center gap-3 animate-pulse">
                <div className="w-12 h-12 rounded-lg bg-white/10 flex-shrink-0" />
                <div className="h-4 bg-white/10 rounded w-20" />
              </div>
            ))
          ) : (
            trendingSongs.map((song, i) => (
              <motion.div
                variants={itemVariants}
                initial="hidden"
                animate="visible"
                transition={{ delay: i * 0.05 }}
                whileTap={{ scale: 0.95 }}
                key={song.id}
                onClick={() => handlePlay(songs.findIndex(s => s.id === song.id))}
                className="glass-card rounded-xl p-2 flex items-center gap-3 shadow-sm cursor-pointer hover:bg-white/10 transition-colors group"
              >
                <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0 shadow-lg">
                  <img className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" src={song.thumbnail} alt={song.title} loading="lazy" referrerPolicy="no-referrer" />
                </div>
                <span className="text-sm font-bold truncate pr-2 text-slate-100">{song.title}</span>
              </motion.div>
            ))
          )}
        </div>
      </section>

      {/* Trending Section */}
      <section>
        <div className="flex justify-between items-end mb-4 px-1">
          <div>
            <h2 className="text-2xl font-bold tracking-tight">🔥 Trending</h2>
            <p className="text-xs text-slate-500 mt-0.5">Paling banyak diputar</p>
          </div>
          <button onClick={() => navigate('/library')} className="text-[10px] uppercase font-bold tracking-widest text-[#ff4e00] hover:brightness-125 transition-all">Lihat Semua</button>
        </div>
        <div className="flex gap-4 overflow-x-auto hide-scrollbar -mx-4 px-4 pb-2">
          {isLoading ? (
            Array.from({ length: 5 }).map((_, i) => <div key={i} className="flex-shrink-0 w-36 h-36 rounded-xl bg-white/5 animate-pulse" />)
          ) : (
            trendingSongs.map((song, i) => (
              <SongCard key={song.id} song={song} index={songs.findIndex(s => s.id === song.id)} onPlay={handlePlay} />
            ))
          )}
        </div>
      </section>

      {/* New Releases Featured Banner */}
      {newestSong && newestIndex >= 0 && (
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-2xl font-bold tracking-tight mb-4 px-1">✨ Terbaru</h2>
          <div className="relative rounded-[1.5rem] overflow-hidden aspect-video shadow-2xl group cursor-pointer" onClick={() => handlePlay(newestIndex)}>
            <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" src={newestSong.thumbnail} alt={newestSong.title} loading="lazy" referrerPolicy="no-referrer" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent flex flex-col justify-end p-6">
              <span className="text-[#ff4e00] font-bold text-xs uppercase tracking-widest mb-2 flex items-center gap-2">
                <span className="w-2 h-2 bg-[#ff4e00] rounded-full animate-pulse" />
                Exclusive Premiere
              </span>
              <h3 className="text-white text-2xl font-extrabold leading-tight mb-3 truncate">{newestSong.title}</h3>
              <p className="text-slate-300 text-sm mb-4">{newestSong.artist}</p>
              <button className="bg-[#ff4e00] hover:brightness-110 text-black px-6 py-2.5 rounded-full font-bold flex items-center gap-2 w-max transition-all active:scale-95 text-sm shadow-[0_0_20px_rgba(255,78,0,0.3)]">
                <span className="material-symbols-outlined text-[18px]" style={{ fontVariationSettings: "'FILL' 1" }}>play_arrow</span>
                Dengarkan Sekarang
              </button>
            </div>
          </div>
        </motion.section>
      )}

      {/* Rekomendasi */}
      <section>
        <div className="flex justify-between items-end mb-4 px-1">
          <div>
            <h2 className="text-2xl font-bold tracking-tight">💡 Rekomendasi</h2>
            <p className="text-xs text-slate-500 mt-0.5">Pilihan untuk kamu</p>
          </div>
        </div>
        <div className="flex gap-4 overflow-x-auto hide-scrollbar -mx-4 px-4 pb-2">
          {isLoading ? (
            Array.from({ length: 5 }).map((_, i) => <div key={i} className="flex-shrink-0 w-36 h-36 rounded-xl bg-white/5 animate-pulse" />)
          ) : (
            recommendedSongs.map((song) => (
              <SongCard key={`rec-${song.id}`} song={song} index={songs.findIndex(s => s.id === song.id)} onPlay={handlePlay} />
            ))
          )}
        </div>
      </section>

      {/* Popular Artists — with photos */}
      <section>
        <div className="flex justify-between items-end mb-4 px-1">
          <h2 className="text-2xl font-bold tracking-tight">Popular Artists</h2>
        </div>
        <div className="flex gap-5 overflow-x-auto hide-scrollbar -mx-4 px-4 pb-2">
          {isLoading ? (
            Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="flex flex-col items-center gap-2 flex-shrink-0 w-24">
                <div className="w-20 h-20 rounded-full bg-white/5 animate-pulse" />
                <div className="h-3 w-16 bg-white/5 rounded animate-pulse" />
              </div>
            ))
          ) : (
            artists.map(({ artist, thumbnail, count }) => (
              <ArtistCard
                key={artist}
                artist={artist}
                thumbnail={thumbnail}
                playCount={count}
                onClick={() => navigate(`/library?filter=${encodeURIComponent(artist)}`)}
              />
            ))
          )}
        </div>
      </section>

      {/* Top Albums */}
      {albums.length > 0 && (
        <section>
          <div className="flex justify-between items-end mb-4 px-1">
            <h2 className="text-2xl font-black uppercase tracking-tighter">Top Albums</h2>
          </div>
          <div className="flex gap-5 overflow-x-auto hide-scrollbar -mx-4 px-4 pb-2">
            {albums.map((album, i) => (
              <motion.div
                key={i}
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => navigate(`/library?view=all&filter=${album.name}`)}
                className="flex-shrink-0 w-40 group cursor-pointer"
              >
                <div className="w-40 h-40 rounded-2xl overflow-hidden mb-2 shadow-xl relative bg-zinc-800">
                  <img className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" src={album.thumbnail} alt={album.name || ''} loading="lazy" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-col justify-end p-3">
                    <p className="text-[9px] font-black text-[#ff4e00] uppercase tracking-widest mb-0.5">Album</p>
                    <p className="text-white text-xs font-black line-clamp-2">{album.name}</p>
                  </div>
                </div>
                <p className="text-xs font-bold text-slate-400 truncate">{album.artist}</p>
              </motion.div>
            ))}
          </div>
        </section>
      )}

      {/* Time Travel + Mood */}
      <section className="bg-white/5 border border-white/10 rounded-[2rem] p-5 shadow-xl">
        <div className="flex flex-col gap-5">
          <div>
            <h3 className="text-lg font-black text-slate-100 mb-1">⏱ Time Travel</h3>
            <div className="flex gap-2 overflow-x-auto hide-scrollbar py-1">
              {['All', '2025', '2024', '2023', '2022', '2021', '2020'].map(year => (
                <button key={year} onClick={() => navigate(`/library?year=${year}`)} className="px-4 py-1.5 rounded-full text-[10px] font-bold text-white bg-white/10 hover:bg-[#ff4e00] hover:text-black transition-all uppercase tracking-widest whitespace-nowrap active:scale-95 flex-shrink-0">
                  {year}
                </button>
              ))}
            </div>
          </div>
          <div className="border-t border-white/5 pt-4">
            <h3 className="text-lg font-black text-slate-100 mb-1">🎭 Mood</h3>
            <div className="flex gap-2 overflow-x-auto hide-scrollbar py-1">
              {['All', 'Pop', 'R&B', 'Lofi', 'Jazz', 'Electronic', 'HipHop'].map(genre => (
                <button key={genre} onClick={() => navigate(`/library?genre=${genre}`)} className="px-4 py-1.5 rounded-full text-[10px] font-bold text-white bg-white/10 hover:bg-[#ff4e00] hover:text-black transition-all uppercase tracking-widest whitespace-nowrap active:scale-95 flex-shrink-0">
                  {genre}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* All Songs — Virtual List with Infinite Scroll */}
      <section>
        <div className="flex justify-between items-end mb-4 px-1">
          <div>
            <h2 className="text-2xl font-bold tracking-tight">Semua Lagu</h2>
            <p className="text-xs text-slate-500 mt-0.5">{songs.length} lagu tersedia</p>
          </div>
        </div>

        {isLoading ? (
          <div className="space-y-1">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="flex items-center gap-3 px-3 py-2.5 animate-pulse">
                <div className="w-12 h-12 rounded-lg bg-white/5 flex-shrink-0" />
                <div className="flex-1 space-y-1.5">
                  <div className="h-3.5 bg-white/5 rounded w-3/4" />
                  <div className="h-3 bg-white/5 rounded w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : displayedSongs.length > 0 ? (
          <>
            <List
              height={Math.min(displayedSongs.length * 68, 600)}
              itemCount={displayedSongs.length}
              itemSize={68}
              width="100%"
              itemData={{ songs: displayedSongs, onPlay: handlePlay }}
            >
              {SongRow}
            </List>
            {/* Infinite scroll sentinel */}
            <div ref={sentinelRef} className="h-4" />
            {hasMore && (
              <div className="flex justify-center py-4">
                <div className="flex gap-1">
                  {[0, 1, 2].map(i => (
                    <div key={i} className="w-1.5 h-1.5 bg-[#ff4e00] rounded-full animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
                  ))}
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="text-center text-sm opacity-50 py-8">Belum ada lagu. Pergi ke Upload untuk menambahkan.</div>
        )}
      </section>
    </main>
  );
}
