import { useState, useEffect, useRef, useCallback } from 'react';
import { useMusicStore, Song } from '../store/useMusicStore';

const PAGE_SIZE = 20;

/**
 * Paginate the in-memory songs array for virtual / infinite scroll.
 * Reads from the global store so we never re-fetch from Firebase.
 */
export function useInfiniteSongs() {
  const songs = useMusicStore((state) => state.songs);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const sentinelRef = useRef<HTMLDivElement | null>(null);

  const displayedSongs: Song[] = songs.slice(0, page * PAGE_SIZE);

  useEffect(() => {
    setHasMore(displayedSongs.length < songs.length);
  }, [displayedSongs.length, songs.length]);

  const loadMore = useCallback(() => {
    if (hasMore) setPage((p) => p + 1);
  }, [hasMore]);

  // IntersectionObserver for auto-load
  useEffect(() => {
    const el = sentinelRef.current;
    if (!el || !hasMore) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) loadMore();
      },
      { rootMargin: '200px' }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [loadMore, hasMore]);

  return { displayedSongs, hasMore, loadMore, sentinelRef, totalCount: songs.length };
}
