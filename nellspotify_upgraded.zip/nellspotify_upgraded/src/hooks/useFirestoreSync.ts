import { useEffect, useRef } from 'react';
import {
  collection,
  onSnapshot,
  query,
  orderBy,
  doc,
  limit,
} from 'firebase/firestore';
import { db } from '../services/firebase';
import { useMusicStore, Song, ForumMessage, AppNotification } from '../store/useMusicStore';
import toast from 'react-hot-toast';

const INITIAL_SONG_LIMIT = 40; // fetch first 40 on startup — more than enough for initial render

/**
 * Subscribes to remote Firestore data — resilient to offline / errors.
 * Local songs (persisted in zustand) are NEVER wiped because Firestore is unavailable.
 */
export function useFirestoreSync() {
  const { addSongs, filter, setSettings, addNotification, setForumMessages, setIsLoading } =
    useMusicStore();
  const isFirstLoad = useRef(true);

  useEffect(() => {
    setIsLoading(false);

    const unsubs: Array<() => void> = [];

    try {
      // 1. Songs — initial paginated fetch with limit
      let qSongs;
      if (filter === 'artist') {
        qSongs = query(
          collection(db, 'songs'),
          orderBy('artist', 'asc'),
          orderBy('createdAt', 'desc'),
          limit(INITIAL_SONG_LIMIT)
        );
      } else {
        qSongs = query(
          collection(db, 'songs'),
          orderBy('createdAt', filter === 'newest' ? 'desc' : 'asc'),
          limit(INITIAL_SONG_LIMIT)
        );
      }

      const unsubSongs = onSnapshot(
        qSongs,
        (snapshot) => {
          const fetchedSongs = snapshot.docs.map((d) => ({
            id: d.id,
            ...d.data(),
          })) as Song[];

          if (fetchedSongs.length > 0) {
            addSongs(fetchedSongs);
          }

          if (!isFirstLoad.current) {
            snapshot.docChanges().forEach((change) => {
              if (change.type === 'added') {
                const data: any = change.doc.data();
                toast.success(`New song: ${data.title}`);
              }
            });
          }
          isFirstLoad.current = false;
        },
        (err) => {
          console.warn('[firestore songs] disabled or unavailable:', err?.message);
        }
      );
      unsubs.push(unsubSongs);

      // 2. App Config
      const unsubConfig = onSnapshot(
        doc(db, 'appConfig', 'main'),
        (docSnap) => {
          if (docSnap.exists()) {
            const data = docSnap.data();
            setSettings({
              appLogo: data.appLogo || '',
              instagram: data.instagram || '',
              tiktok: data.tiktok || '',
              theme: data.theme || 'glass',
              geminiApiKey: data.geminiApiKey || '',
              youtubeApiKey: data.youtubeApiKey || useMusicStore.getState().youtubeApiKey || '',
            });
          }
        },
        (err) => console.warn('[firestore config] unavailable:', err?.message)
      );
      unsubs.push(unsubConfig);

      // 3. Notifications
      const qNotifs = query(collection(db, 'notifications'), orderBy('timestamp', 'desc'), limit(10));
      const unsubNotifs = onSnapshot(
        qNotifs,
        (snapshot) => {
          snapshot.docChanges().forEach((change) => {
            if (change.type === 'added') {
              const data = change.doc.data() as Omit<AppNotification, 'id' | 'unread'>;
              if (Date.now() - data.timestamp < 15000) {
                addNotification({ message: data.message, timestamp: data.timestamp, type: data.type as any });
              }
            }
          });
        },
        (err) => console.warn('[firestore notifs] unavailable:', err?.message)
      );
      unsubs.push(unsubNotifs);

      // 4. Forum
      const qForum = query(collection(db, 'forum'), orderBy('timestamp', 'asc'));
      const unsubForum = onSnapshot(
        qForum,
        (snapshot) => {
          const msgs = snapshot.docs.map((d) => ({ id: d.id, ...d.data() })) as ForumMessage[];
          setForumMessages(msgs);
        },
        (err) => console.warn('[firestore forum] unavailable:', err?.message)
      );
      unsubs.push(unsubForum);
    } catch (err) {
      console.warn('[firestore] init failed, running in local-only mode:', err);
    }

    return () => {
      for (const u of unsubs) { try { u(); } catch {} }
    };
  }, [filter, addSongs, setSettings, addNotification, setForumMessages, setIsLoading]);
}
