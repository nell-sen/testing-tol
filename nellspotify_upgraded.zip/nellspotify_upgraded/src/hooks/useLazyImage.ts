import { useEffect, useRef } from 'react';

/**
 * Fade-in images once they load.
 * Apply this ref to an <img> element — the image fades in smoothly.
 */
export function useLazyImage() {
  const imgRef = useRef<HTMLImageElement>(null);

  useEffect(() => {
    const img = imgRef.current;
    if (!img) return;

    const onLoad = () => {
      img.classList.add('loaded');
    };

    if (img.complete) {
      img.classList.add('loaded');
    } else {
      img.addEventListener('load', onLoad);
    }

    return () => img.removeEventListener('load', onLoad);
  }, []);

  return imgRef;
}
