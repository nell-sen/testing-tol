import { lazy, Suspense, useEffect } from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';
import { Toaster } from 'react-hot-toast';
import { Layout } from './components/Layout';
import { useFirestoreSync } from './hooks/useFirestoreSync';
import { useMusicStore } from './store/useMusicStore';

// Lazy load all pages
const Home = lazy(() => import('./pages/Home').then(m => ({ default: m.Home })));
const Search = lazy(() => import('./pages/Search').then(m => ({ default: m.Search })));
const Library = lazy(() => import('./pages/Library').then(m => ({ default: m.Library })));
const Player = lazy(() => import('./pages/Player').then(m => ({ default: m.Player })));
const Lyrics = lazy(() => import('./pages/Lyrics').then(m => ({ default: m.Lyrics })));
const Admin = lazy(() => import('./pages/Admin').then(m => ({ default: m.Admin })));
const NotFound = lazy(() => import('./pages/NotFound'));

function PageSkeleton() {
  return (
    <div className="pt-24 px-6 pb-40 space-y-6 w-full max-w-screen-2xl mx-auto">
      <div className="h-8 bg-white/10 rounded-xl animate-pulse w-48" />
      <div className="grid grid-cols-2 gap-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="h-16 bg-white/5 rounded-xl animate-pulse" />
        ))}
      </div>
      <div className="h-6 bg-white/10 rounded-xl animate-pulse w-32" />
      <div className="flex gap-4 overflow-hidden">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="flex-shrink-0 w-40 h-40 bg-white/5 rounded-xl animate-pulse" />
        ))}
      </div>
    </div>
  );
}

function AppContent() {
  useFirestoreSync();
  const location = useLocation();
  const theme = useMusicStore((state) => state.theme);

  useEffect(() => {
    document.body.className = `theme-${theme}`;
  }, [theme]);

  return (
    <AnimatePresence mode="wait">
      <Suspense fallback={<PageSkeleton />}>
        <Routes location={location}>
          <Route path="/" element={<Layout />}>
            <Route index element={<Home />} />
            <Route path="index" element={<Home />} />
            <Route path="search" element={<Search />} />
            <Route path="library" element={<Library />} />
            <Route path="admin" element={<Admin />} />
            <Route path="player" element={<Player />} />
            <Route path="lyrics" element={<Lyrics />} />
          </Route>
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Suspense>
    </AnimatePresence>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Toaster position="top-center" toastOptions={{ style: { background: '#111', color: '#fff' } }} />
      <AppContent />
    </BrowserRouter>
  );
}
