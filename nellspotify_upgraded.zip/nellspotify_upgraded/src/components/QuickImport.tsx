import { useState } from 'react';
import toast from 'react-hot-toast';
import { useMusicStore, Song } from '../store/useMusicStore';
import {
  detectYouTubeUrl,
  fetchYouTubePlaylist,
  fetchYouTubeVideo,
} from '../services/youtubeService';

/**
 * Quick YouTube import widget — no admin login required.
 * Imports go straight into the local zustand store and start playing.
 */
export function QuickImport() {
  const [url, setUrl] = useState('');
  const [busy, setBusy] = useState(false);
  const { youtubeApiKey, addSongs, setCurrentSongIndex, setIsPlaying } = useMusicStore();

  const handleImport = async () => {
    const input = url.trim();
    if (!input) {
      toast.error('Tempel link YouTube dulu');
      return;
    }
    const detected = detectYouTubeUrl(input);
    if (detected.kind === 'invalid') {
      toast.error('Link YouTube tidak valid');
      return;
    }

    try {
      setBusy(true);
      let items;
      if (detected.kind === 'playlist') {
        items = await fetchYouTubePlaylist(youtubeApiKey, input);
      } else {
        items = [await fetchYouTubeVideo(youtubeApiKey, detected.videoId)];
      }

      if (!items.length) {
        toast.error('Tidak ada video yang bisa diimpor');
        return;
      }

      const localSongs: Song[] = items.map((item, i) => ({
        id: `yt-${item.videoId}`,
        title: item.title,
        artist: item.artist,
        album: detected.kind === 'playlist' ? 'YouTube Playlist' : 'YouTube Single',
        duration: 'Unknown',
        releaseYear: new Date().getFullYear().toString(),
        genre: 'Various',
        audioUrl: `https://www.youtube.com/watch?v=${item.videoId}`,
        thumbnail: item.thumbnail,
        createdAt: Date.now() + i,
      }));

      addSongs(localSongs);
      toast.success(`${localSongs.length} lagu siap diputar!`);
      setUrl('');

      // Auto-play first imported song (this is inside a user-gesture handler).
      const all = useMusicStore.getState().songs;
      const idx = all.findIndex((s) => s.id === localSongs[0].id);
      if (idx >= 0) {
        setCurrentSongIndex(idx);
        setIsPlaying(true);
      }
    } catch (err: any) {
      console.error(err);
      toast.error(err?.message || 'Gagal mengimpor');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="glass-card rounded-2xl p-4 mb-4">
      <div className="flex items-center justify-between mb-3 px-1">
        <h3 className="text-[10px] font-black uppercase tracking-widest text-[#ff4e00]">
          Quick Import
        </h3>
        <span className="material-symbols-outlined text-[#ff4e00] text-base">queue_music</span>
      </div>
      <div className="flex gap-2">
        <input
          type="text"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') handleImport();
          }}
          className="flex-1 bg-black/40 border border-white/10 rounded-xl px-3 py-2.5 text-sm font-medium focus:outline-none focus:border-[#ff4e00] text-white placeholder:text-slate-500"
          placeholder="Tempel link playlist / video YouTube..."
        />
        <button
          onClick={handleImport}
          disabled={busy}
          className="bg-[#ff4e00] text-black font-black px-4 rounded-xl hover:brightness-110 active:scale-95 transition-all disabled:opacity-50 text-[10px] uppercase tracking-widest"
        >
          {busy ? '...' : 'Play'}
        </button>
      </div>
      <p className="text-[9px] text-slate-500 mt-2 px-1">
        Mendukung playlist (<code>?list=</code>) dan video tunggal. Lagu disimpan lokal & langsung diputar.
      </p>
    </div>
  );
}
