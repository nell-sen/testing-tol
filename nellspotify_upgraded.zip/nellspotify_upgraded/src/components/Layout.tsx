import { memo } from 'react';
import { Outlet } from 'react-router-dom';
import { BottomNav } from './BottomNav';
import { MiniPlayer } from './MiniPlayer';
import { GlobalAudioPlayer } from './GlobalAudioPlayer';
import { GlobalSearch } from './GlobalSearch';
import { CreatorOverlay } from './CreatorOverlay';
import { NotificationsOverlay } from './NotificationsOverlay';
import { Toaster } from 'react-hot-toast';

// Layout itself never needs to re-render for store changes
export const Layout = memo(function Layout() {
  return (
    <div className="relative min-h-[100dvh] overflow-x-hidden flex flex-col bg-background text-on-background">
      {/* Hidden global audio engine — never unmounts */}
      <GlobalAudioPlayer />
      
      {/* Overlays */}
      <GlobalSearch />
      <CreatorOverlay />
      <NotificationsOverlay />
      <Toaster
        position="top-center"
        toastOptions={{
          className: 'font-sans',
          style: { background: '#ff4e00', color: '#000', borderRadius: '99px', fontWeight: 'bold' },
        }}
      />

      {/* Ambient background — CSS-only, no JS cost */}
      <div className="fixed inset-0 pointer-events-none opacity-40 z-0" aria-hidden="true">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-[#ff4e00] rounded-full blur-[120px] mix-blend-screen" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-[#3a1510] rounded-full blur-[120px] mix-blend-screen" />
      </div>

      {/* Page content */}
      <div className="flex-1 flex flex-col w-full relative z-10">
        <Outlet />
      </div>

      {/* Fixed bottom UI */}
      <MiniPlayer />
      <BottomNav />
    </div>
  );
});
