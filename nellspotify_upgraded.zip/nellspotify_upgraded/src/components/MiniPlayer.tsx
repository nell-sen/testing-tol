import { memo } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useMusicStore } from '../store/useMusicStore';
import { motion, AnimatePresence } from 'framer-motion';

// Use fine-grained Zustand selectors to avoid unnecessary re-renders
export const MiniPlayer = memo(function MiniPlayer() {
  const currentSongIndex = useMusicStore((s) => s.currentSongIndex);
  const isPlaying = useMusicStore((s) => s.isPlaying);
  const setIsPlaying = useMusicStore((s) => s.setIsPlaying);
  const songs = useMusicStore((s) => s.songs);
  const location = useLocation();

  if (
    location.pathname === '/player' ||
    location.pathname === '/lyrics' ||
    currentSongIndex < 0 ||
    currentSongIndex >= songs.length
  ) {
    return null;
  }

  const song = songs[currentSongIndex];

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: 120, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 120, opacity: 0 }}
        transition={{ type: 'spring', damping: 20, stiffness: 150 }}
        className="fixed bottom-24 left-0 right-0 z-40 px-2.5 pointer-events-none"
      >
        <div className="w-full max-w-screen-2xl mx-auto pointer-events-auto">
          <Link to="/player" className="block outline-none group">
            <div className="bg-zinc-900/95 backdrop-blur-3xl rounded-2xl shadow-2xl border border-white/10 px-3 py-2.5 flex items-center justify-between gap-3 group-hover:bg-white/5 transition-colors">
              <div className="flex items-center gap-3 overflow-hidden min-w-0 flex-1">
                <motion.div
                  layoutId="mini-player-art"
                  className="w-11 h-11 flex-shrink-0 rounded-lg overflow-hidden shadow-lg border border-white/10"
                >
                  <img
                    src={song.thumbnail}
                    alt={song.title}
                    loading="lazy"
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                </motion.div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-bold truncate text-slate-100 group-hover:text-[#ff4e00] transition-colors leading-tight">{song.title}</p>
                  <p className="text-xs text-slate-400 font-medium truncate opacity-70 mt-0.5">{song.artist}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 flex-shrink-0">
                <button
                  onClick={(e) => { e.preventDefault(); }}
                  className="material-symbols-outlined text-slate-400 hover:text-white transition-colors text-[22px]"
                >
                  cast
                </button>
                <button
                  onClick={(e) => {
                    e.preventDefault();
                    const ref: any = (window as any).globalAudioRef;
                    if (!isPlaying && ref?.play) {
                      try { ref.play(); } catch {}
                    } else if (isPlaying && ref?.pause) {
                      try { ref.pause(); } catch {}
                    }
                    setIsPlaying(!isPlaying);
                  }}
                  className="material-symbols-outlined text-black bg-white w-9 h-9 rounded-full flex items-center justify-center shadow-white/10 shadow-lg text-base hover:scale-110 active:scale-95 transition-all"
                  style={{ fontVariationSettings: "'FILL' 1" }}
                >
                  {isPlaying ? 'pause' : 'play_arrow'}
                </button>
              </div>
            </div>
          </Link>
        </div>
      </motion.div>
    </AnimatePresence>
  );
});
